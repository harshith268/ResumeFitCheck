import sqlite3
import json
from datetime import datetime

DATABASE_PATH = 'resumefit.db'

def init_db():
    """Initialize the database with required tables"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Table for usage statistics
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usage_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            total_resumes_analyzed INTEGER DEFAULT 0,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Table for analysis history
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS analysis_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            overall_score REAL,
            summary_score REAL,
            skills_score REAL,
            experience_score REAL,
            missing_keywords TEXT,
            resume_text TEXT,
            job_description TEXT
        )
    ''')
    
    # Table for resumes
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS resumes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            name TEXT,
            email TEXT,
            phone TEXT,
            summary TEXT,
            skills TEXT,
            experience TEXT,
            education TEXT,
            projects TEXT,
            template_type TEXT,
            ats_score REAL
        )
    ''')
    
    # Initialize usage stats if not exists
    cursor.execute('SELECT COUNT(*) FROM usage_stats')
    if cursor.fetchone()[0] == 0:
        cursor.execute('INSERT INTO usage_stats (total_resumes_analyzed) VALUES (0)')
    
    conn.commit()
    conn.close()

def get_usage_stats():
    """Get total resumes analyzed"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT total_resumes_analyzed FROM usage_stats WHERE id = 1')
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else 0

def increment_usage():
    """Increment the usage counter"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE usage_stats 
        SET total_resumes_analyzed = total_resumes_analyzed + 1,
            last_updated = CURRENT_TIMESTAMP
        WHERE id = 1
    ''')
    conn.commit()
    conn.close()

def save_analysis(overall_score, summary_score, skills_score, experience_score, 
                  missing_keywords, resume_text, job_description):
    """Save an analysis to history"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    missing_kw_json = json.dumps(missing_keywords)
    
    cursor.execute('''
        INSERT INTO analysis_history 
        (overall_score, summary_score, skills_score, experience_score, 
         missing_keywords, resume_text, job_description)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (overall_score, summary_score, skills_score, experience_score,
          missing_kw_json, resume_text, job_description))
    
    conn.commit()
    conn.close()

def get_recent_analyses(limit=5):
    """Get recent analyses"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, analysis_date, overall_score, summary_score, 
               skills_score, experience_score, missing_keywords
        FROM analysis_history
        ORDER BY analysis_date DESC
        LIMIT ?
    ''', (limit,))
    
    results = cursor.fetchall()
    conn.close()
    
    analyses = []
    for row in results:
        analyses.append({
            'id': row[0],
            'date': row[1],
            'overall_score': row[2],
            'summary_score': row[3],
            'skills_score': row[4],
            'experience_score': row[5],
            'missing_keywords': json.loads(row[6]) if row[6] else []
        })
    
    return analyses

def get_average_score():
    """Get average overall score from all analyses"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT AVG(overall_score) FROM analysis_history')
    result = cursor.fetchone()
    conn.close()
    return round(result[0], 1) if result[0] else 0

def save_resume(resume_data):
    """Save a created resume to database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO resumes 
        (name, email, phone, summary, skills, experience, education, projects, template_type, ats_score)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        resume_data.get('name', ''),
        resume_data.get('email', ''),
        resume_data.get('phone', ''),
        resume_data.get('summary', ''),
        resume_data.get('skills', ''),
        resume_data.get('experience', ''),
        resume_data.get('education', ''),
        resume_data.get('projects', ''),
        resume_data.get('template', 'modern'),
        resume_data.get('ats_score', 0)
    ))
    
    resume_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return resume_id
