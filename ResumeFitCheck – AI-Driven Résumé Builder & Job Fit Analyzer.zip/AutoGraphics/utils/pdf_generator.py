from weasyprint import HTML, CSS
from io import BytesIO
import os

def generate_resume_pdf(resume_data, template='modern'):
    """Generate PDF from resume data using WeasyPrint"""
    
    html_content = generate_html_template(resume_data, template)
    
    # Create PDF
    pdf_file = BytesIO()
    HTML(string=html_content).write_pdf(pdf_file)
    pdf_file.seek(0)
    
    return pdf_file

def generate_html_template(resume_data, template='modern'):
    """Generate HTML content based on selected template"""
    
    name = resume_data.get('name', 'Your Name')
    email = resume_data.get('email', '')
    phone = resume_data.get('phone', '')
    summary = resume_data.get('summary', '')
    skills = resume_data.get('skills', '')
    experience = resume_data.get('experience', '')
    education = resume_data.get('education', '')
    projects = resume_data.get('projects', '')
    
    if template == 'modern':
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                @page {{ margin: 1.5cm; }}
                body {{ 
                    font-family: 'Arial', sans-serif; 
                    line-height: 1.6; 
                    color: #333;
                    margin: 0;
                    padding: 0;
                }}
                .header {{ 
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white; 
                    padding: 30px; 
                    text-align: center;
                    margin-bottom: 20px;
                }}
                h1 {{ margin: 0; font-size: 32px; }}
                .contact {{ margin-top: 10px; font-size: 14px; }}
                .section {{ margin-bottom: 25px; }}
                .section-title {{ 
                    font-size: 18px; 
                    font-weight: bold; 
                    color: #667eea; 
                    border-bottom: 2px solid #667eea;
                    padding-bottom: 5px;
                    margin-bottom: 10px;
                }}
                .content {{ font-size: 14px; white-space: pre-wrap; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>{name}</h1>
                <div class="contact">{email} | {phone}</div>
            </div>
            
            {f'<div class="section"><div class="section-title">SUMMARY</div><div class="content">{summary}</div></div>' if summary else ''}
            {f'<div class="section"><div class="section-title">SKILLS</div><div class="content">{skills}</div></div>' if skills else ''}
            {f'<div class="section"><div class="section-title">EXPERIENCE</div><div class="content">{experience}</div></div>' if experience else ''}
            {f'<div class="section"><div class="section-title">EDUCATION</div><div class="content">{education}</div></div>' if education else ''}
            {f'<div class="section"><div class="section-title">PROJECTS</div><div class="content">{projects}</div></div>' if projects else ''}
        </body>
        </html>
        """
    
    elif template == 'minimal':
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                @page {{ margin: 2cm; }}
                body {{ 
                    font-family: 'Georgia', serif; 
                    line-height: 1.8; 
                    color: #222;
                    margin: 0;
                    padding: 20px;
                }}
                h1 {{ 
                    font-size: 28px; 
                    margin-bottom: 5px;
                    border-bottom: 1px solid #222;
                    padding-bottom: 10px;
                }}
                .contact {{ 
                    font-size: 12px; 
                    color: #666;
                    margin-bottom: 30px;
                }}
                .section {{ margin-bottom: 25px; }}
                .section-title {{ 
                    font-size: 16px; 
                    font-weight: bold; 
                    text-transform: uppercase;
                    letter-spacing: 1px;
                    margin-bottom: 10px;
                }}
                .content {{ font-size: 13px; white-space: pre-wrap; }}
            </style>
        </head>
        <body>
            <h1>{name}</h1>
            <div class="contact">{email} | {phone}</div>
            
            {f'<div class="section"><div class="section-title">Summary</div><div class="content">{summary}</div></div>' if summary else ''}
            {f'<div class="section"><div class="section-title">Skills</div><div class="content">{skills}</div></div>' if skills else ''}
            {f'<div class="section"><div class="section-title">Experience</div><div class="content">{experience}</div></div>' if experience else ''}
            {f'<div class="section"><div class="section-title">Education</div><div class="content">{education}</div></div>' if education else ''}
            {f'<div class="section"><div class="section-title">Projects</div><div class="content">{projects}</div></div>' if projects else ''}
        </body>
        </html>
        """
    
    else:  # corporate
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                @page {{ margin: 2cm; }}
                body {{ 
                    font-family: 'Helvetica', 'Arial', sans-serif; 
                    line-height: 1.6; 
                    color: #000;
                    margin: 0;
                    padding: 0;
                }}
                .header {{ 
                    background: #2c3e50;
                    color: white; 
                    padding: 25px; 
                    margin-bottom: 25px;
                }}
                h1 {{ margin: 0; font-size: 30px; font-weight: 600; }}
                .contact {{ margin-top: 8px; font-size: 13px; }}
                .section {{ margin-bottom: 20px; padding: 0 25px; }}
                .section-title {{ 
                    font-size: 16px; 
                    font-weight: bold; 
                    background: #ecf0f1;
                    padding: 8px 12px;
                    margin-bottom: 12px;
                    margin-left: -25px;
                    margin-right: -25px;
                }}
                .content {{ font-size: 13px; white-space: pre-wrap; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>{name}</h1>
                <div class="contact">{email} | {phone}</div>
            </div>
            
            {f'<div class="section"><div class="section-title">SUMMARY</div><div class="content">{summary}</div></div>' if summary else ''}
            {f'<div class="section"><div class="section-title">SKILLS</div><div class="content">{skills}</div></div>' if skills else ''}
            {f'<div class="section"><div class="section-title">EXPERIENCE</div><div class="content">{experience}</div></div>' if experience else ''}
            {f'<div class="section"><div class="section-title">EDUCATION</div><div class="content">{education}</div></div>' if education else ''}
            {f'<div class="section"><div class="section-title">PROJECTS</div><div class="content">{projects}</div></div>' if projects else ''}
        </body>
        </html>
        """
    
    return html
