import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import PyPDF2
import io

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)

try:
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab', quiet=True)

def extract_text_from_pdf(file_storage):
    """Extract text from uploaded PDF file. Returns None on error."""
    try:
        pdf_reader = PyPDF2.PdfReader(file_storage)
        text = ""
        for page in pdf_reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text
        
        if not text.strip():
            return None
        
        return text.strip()
    except Exception as e:
        print(f"PDF extraction error: {str(e)}")
        return None

def clean_text(text):
    """Clean and normalize text"""
    if not text:
        return ""
    
    # Convert to lowercase
    text = text.lower()
    
    # Remove special characters and extra whitespace
    text = re.sub(r'[^a-zA-Z0-9\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    
    return text.strip()

def tokenize_and_remove_stopwords(text):
    """Tokenize text and remove stopwords"""
    if not text:
        return []
    
    # Tokenize
    tokens = word_tokenize(text)
    
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words and len(word) > 2]
    
    return filtered_tokens

def calculate_keyword_match(resume_text, job_description):
    """Calculate keyword matching using TF-IDF and cosine similarity"""
    if not resume_text or not job_description:
        return 0, []
    
    # Clean texts
    resume_clean = clean_text(resume_text)
    job_clean = clean_text(job_description)
    
    # Create TF-IDF vectorizer
    vectorizer = TfidfVectorizer(max_features=100, ngram_range=(1, 2))
    
    try:
        # Fit and transform
        tfidf_matrix = vectorizer.fit_transform([resume_clean, job_clean])
        
        # Calculate cosine similarity
        similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        
        # Get feature names (keywords)
        feature_names = vectorizer.get_feature_names_out()
        
        # Get job description keywords
        job_tfidf = tfidf_matrix[1].toarray()[0]
        job_keywords = [(feature_names[i], job_tfidf[i]) for i in range(len(job_tfidf)) if job_tfidf[i] > 0]
        job_keywords.sort(key=lambda x: x[1], reverse=True)
        
        # Get resume keywords
        resume_tfidf = tfidf_matrix[0].toarray()[0]
        resume_keywords = set([feature_names[i] for i in range(len(resume_tfidf)) if resume_tfidf[i] > 0])
        
        # Find missing keywords
        missing_keywords = [kw[0] for kw in job_keywords[:15] if kw[0] not in resume_keywords]
        
        # Convert similarity to percentage
        score = round(similarity * 100, 1)
        
        return score, missing_keywords
    
    except Exception as e:
        print(f"Error in keyword matching: {e}")
        return 0, []

def analyze_sections(resume_text, job_description):
    """Analyze individual sections of resume against job description"""
    
    # Extract sections from resume (simple heuristic)
    resume_lower = resume_text.lower()
    
    # Try to extract summary section
    summary_match = re.search(r'(summary|objective|profile)(.*?)(experience|skills|education)', resume_lower, re.DOTALL)
    summary = summary_match.group(2) if summary_match else resume_text[:500]
    
    # Try to extract skills section
    skills_match = re.search(r'(skills|technical skills|core competencies)(.*?)(experience|education|projects)', resume_lower, re.DOTALL)
    skills = skills_match.group(2) if skills_match else resume_text[:500]
    
    # Try to extract experience section
    experience_match = re.search(r'(experience|work experience|employment)(.*?)(education|skills|projects)', resume_lower, re.DOTALL)
    experience = experience_match.group(2) if experience_match else resume_text[:500]
    
    # Calculate scores for each section
    summary_score, _ = calculate_keyword_match(summary, job_description)
    skills_score, _ = calculate_keyword_match(skills, job_description)
    experience_score, _ = calculate_keyword_match(experience, job_description)
    
    return {
        'summary_score': summary_score,
        'skills_score': skills_score,
        'experience_score': experience_score
    }

def generate_detailed_suggestions(resume_text, job_description):
    """Generate comprehensive suggestions for improving resume-job fit"""
    
    suggestions = {
        'missing_keywords': [],
        'skill_gaps': [],
        'experience_recommendations': [],
        'summary_suggestions': [],
        'overall_recommendations': [],
        'action_items': []
    }
    
    if not resume_text or not job_description:
        return suggestions
    
    resume_clean = clean_text(resume_text)
    job_clean = clean_text(job_description)
    resume_lower = resume_text.lower()
    job_lower = job_description.lower()
    
    # Create TF-IDF vectorizer for detailed analysis
    vectorizer = TfidfVectorizer(max_features=150, ngram_range=(1, 3))
    
    try:
        tfidf_matrix = vectorizer.fit_transform([resume_clean, job_clean])
        feature_names = vectorizer.get_feature_names_out()
        
        # Get job description keywords with scores
        job_tfidf = tfidf_matrix[1].toarray()[0]
        job_keywords = [(feature_names[i], job_tfidf[i]) for i in range(len(job_tfidf)) if job_tfidf[i] > 0]
        job_keywords.sort(key=lambda x: x[1], reverse=True)
        
        # Get resume keywords
        resume_tfidf = tfidf_matrix[0].toarray()[0]
        resume_keywords = set([feature_names[i] for i in range(len(resume_tfidf)) if resume_tfidf[i] > 0])
        
        # Identify critical missing keywords (top keywords from job)
        critical_missing = []
        important_missing = []
        
        for kw, score in job_keywords[:30]:
            if kw not in resume_keywords:
                keyword_detail = {
                    'keyword': kw,
                    'importance': 'High' if score > 0.3 else 'Medium',
                    'suggestion': f"Consider adding '{kw}' to your resume"
                }
                if score > 0.3:
                    critical_missing.append(keyword_detail)
                else:
                    important_missing.append(keyword_detail)
        
        suggestions['missing_keywords'] = critical_missing[:10]
        
        # Identify skill gaps
        common_skills = ['python', 'java', 'javascript', 'sql', 'aws', 'docker', 'kubernetes', 
                        'react', 'node', 'angular', 'vue', 'machine learning', 'data analysis',
                        'project management', 'agile', 'scrum', 'leadership', 'communication',
                        'problem solving', 'teamwork', 'git', 'ci cd', 'testing', 'api']
        
        for skill in common_skills:
            if skill in job_lower and skill not in resume_lower:
                suggestions['skill_gaps'].append({
                    'skill': skill.title(),
                    'recommendation': f"Add '{skill.title()}' to your skills section if you have experience with it",
                    'priority': 'High' if any(skill in kw[0] for kw in job_keywords[:10]) else 'Medium'
                })
        
        # Extract action verbs from job description
        action_verbs = ['develop', 'manage', 'lead', 'create', 'implement', 'design', 'analyze',
                       'optimize', 'collaborate', 'build', 'maintain', 'improve', 'drive', 'execute']
        
        job_verbs = [verb for verb in action_verbs if verb in job_lower]
        resume_verbs = [verb for verb in action_verbs if verb in resume_lower]
        missing_verbs = list(set(job_verbs) - set(resume_verbs))
        
        if missing_verbs:
            suggestions['experience_recommendations'].append({
                'title': 'Use More Action Verbs',
                'detail': f"The job description emphasizes: {', '.join(missing_verbs[:5])}. Use these verbs to describe your achievements.",
                'example': f"Instead of 'Responsible for X', write 'Led X' or 'Developed X'"
            })
        
        # Analyze summary/objective
        has_summary = bool(re.search(r'(summary|objective|profile)', resume_lower))
        if not has_summary:
            suggestions['summary_suggestions'].append({
                'title': 'Add a Professional Summary',
                'detail': 'Include a 2-3 sentence summary at the top of your resume highlighting your key qualifications for this role',
                'priority': 'High'
            })
        
        # Check for quantifiable achievements
        has_numbers = bool(re.search(r'\d+%|\d+\+|\$\d+|\d+ years', resume_text))
        if not has_numbers:
            suggestions['experience_recommendations'].append({
                'title': 'Add Quantifiable Achievements',
                'detail': 'Include specific numbers, percentages, or metrics to demonstrate your impact',
                'example': '"Increased sales by 25%" or "Managed a team of 10 developers"'
            })
        
        # Overall recommendations based on missing keywords
        if len(critical_missing) > 5:
            suggestions['overall_recommendations'].append({
                'category': 'Keyword Optimization',
                'recommendation': f'Your resume is missing {len(critical_missing)} critical keywords from the job description. Focus on naturally incorporating these terms.',
                'impact': 'High'
            })
        
        # Check resume length indicators
        word_count = len(resume_text.split())
        if word_count < 200:
            suggestions['overall_recommendations'].append({
                'category': 'Resume Completeness',
                'recommendation': 'Your resume appears brief. Consider expanding on your achievements, responsibilities, and skills to better showcase your qualifications.',
                'impact': 'Medium'
            })
        
        # Generate prioritized action items
        suggestions['action_items'] = []
        
        if critical_missing:
            suggestions['action_items'].append({
                'priority': 1,
                'action': f"Add these high-priority keywords: {', '.join([k['keyword'] for k in critical_missing[:5]])}",
                'section': 'Throughout Resume'
            })
        
        if suggestions['skill_gaps']:
            top_skills = [s['skill'] for s in suggestions['skill_gaps'] if s['priority'] == 'High'][:3]
            if top_skills:
                suggestions['action_items'].append({
                    'priority': 2,
                    'action': f"Add relevant skills: {', '.join(top_skills)}",
                    'section': 'Skills Section'
                })
        
        if not has_numbers:
            suggestions['action_items'].append({
                'priority': 3,
                'action': 'Quantify your achievements with specific numbers and metrics',
                'section': 'Experience Section'
            })
        
        if missing_verbs:
            suggestions['action_items'].append({
                'priority': 4,
                'action': f"Use action verbs like: {', '.join(missing_verbs[:4])}",
                'section': 'Experience Section'
            })
        
    except Exception as e:
        print(f"Error generating suggestions: {e}")
    
    return suggestions

def calculate_ats_score(resume_data):
    """Calculate simple ATS score based on resume completeness"""
    score = 0
    max_score = 100
    
    # Check each field and assign points
    if resume_data.get('name') and len(resume_data.get('name', '')) > 2:
        score += 5
    
    if resume_data.get('email') and '@' in resume_data.get('email', ''):
        score += 5
    
    if resume_data.get('phone') and len(resume_data.get('phone', '')) > 5:
        score += 5
    
    summary = resume_data.get('summary', '')
    if summary and len(summary) > 50:
        score += 20
    elif summary and len(summary) > 20:
        score += 10
    
    skills = resume_data.get('skills', '')
    if skills and len(skills) > 50:
        score += 25
    elif skills and len(skills) > 20:
        score += 15
    
    experience = resume_data.get('experience', '')
    if experience and len(experience) > 100:
        score += 25
    elif experience and len(experience) > 50:
        score += 15
    
    education = resume_data.get('education', '')
    if education and len(education) > 20:
        score += 10
    
    projects = resume_data.get('projects', '')
    if projects and len(projects) > 50:
        score += 10
    
    return min(score, max_score)
