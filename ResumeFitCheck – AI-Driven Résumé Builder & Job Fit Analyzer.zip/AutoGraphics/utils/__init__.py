# Utils module for ResumeFitCheck application
