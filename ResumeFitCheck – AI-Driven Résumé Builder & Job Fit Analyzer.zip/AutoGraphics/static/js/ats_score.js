document.addEventListener('DOMContentLoaded', function() {
    const fields = document.querySelectorAll('.resume-field');
    const nameField = document.getElementById('name');
    const emailField = document.getElementById('email');
    const phoneField = document.getElementById('phone');
    const scoreBar = document.getElementById('atsScoreBar');
    const scoreText = document.getElementById('atsScoreText');
    
    function calculateScore() {
        let score = 0;
        
        if (nameField && nameField.value.trim().length > 2) {
            score += 5;
        }
        
        if (emailField && emailField.value.includes('@')) {
            score += 5;
        }
        
        if (phoneField && phoneField.value.trim().length > 5) {
            score += 5;
        }
        
        const summary = document.getElementById('summary').value.trim();
        if (summary.length > 50) {
            score += 20;
        } else if (summary.length > 20) {
            score += 10;
        }
        
        const skills = document.getElementById('skills').value.trim();
        if (skills.length > 50) {
            score += 25;
        } else if (skills.length > 20) {
            score += 15;
        }
        
        const experience = document.getElementById('experience').value.trim();
        if (experience.length > 100) {
            score += 25;
        } else if (experience.length > 50) {
            score += 15;
        }
        
        const education = document.getElementById('education').value.trim();
        if (education.length > 20) {
            score += 10;
        }
        
        const projects = document.getElementById('projects').value.trim();
        if (projects.length > 50) {
            score += 10;
        }
        
        updateScoreDisplay(Math.min(score, 100));
    }
    
    function updateScoreDisplay(score) {
        scoreBar.style.width = score + '%';
        scoreBar.setAttribute('aria-valuenow', score);
        scoreText.textContent = score + '%';
        
        scoreBar.classList.remove('bg-danger', 'bg-warning', 'bg-success');
        if (score >= 70) {
            scoreBar.classList.add('bg-success');
        } else if (score >= 40) {
            scoreBar.classList.add('bg-warning');
        } else {
            scoreBar.classList.add('bg-danger');
        }
    }
    
    if (nameField) nameField.addEventListener('input', calculateScore);
    if (emailField) emailField.addEventListener('input', calculateScore);
    if (phoneField) phoneField.addEventListener('input', calculateScore);
    
    fields.forEach(field => {
        field.addEventListener('input', calculateScore);
    });
    
    calculateScore();
});
